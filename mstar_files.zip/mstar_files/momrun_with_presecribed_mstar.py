import os
import numpy as np
import netCDF4 as ncd
import time

def tx4mtime(mt,tx_max,day):
    txx=np.zeros(len(mt))
    for i in range(len(mt)):
        if mt[i]<=day:
            txx[i]=mt[i]*(tx_max/day)
        else:
            txx[i]=tx_max
    return txx

pwd=os.getcwd()  #'/Users/aakash/mom6_files/MOM6-examples-eqdisc/ocean_only/neural_network/EPBL/'

epbl_dir=pwd+'mstar_prescribed/epbl/'


mstar_time=np.loadtxt('mstar_time_40.0_50.0_0.2.txt')
mstar_prescribed=np.loadtxt('mstar_interpolated_40.0_50.0_0.2.txt')

tx=tx4mtime(mstar_time,0.2,5)
k=np.arange(0,100) #250)    #len(mstar_time)-1)
#k=np.arange(0,4) 
ii=0  # zeroth oteration


run_executable = '/Users/aakash/mom6_files/ML_diffusivity_development/MOM6-examples/build/ocean_only/MOM6'

    

### with ePBL:
for ii in k:
    
    ### open input.nml and start modifying it
    with open('input.nml') as overfile_input:
        fil=overfile_input.readlines()
    if ii==0:
        fil[2]="         input_filename = 'n' \n"
    else:
        fil[2]="         input_filename = 'r' \n"
    with open('input.nml','w') as overfile2_input:
        overfile2_input.writelines(fil)
    ### close input.nml as it has been modifed.


    ### open MOM_override to modify
    with open('MOM_override') as overfile:
        fil=overfile.readlines()
    #fil[4]='CONST_WIND_TAUX = '+str(tx[ii+1])+' \n'
    fil[23]='#override MSTAR = '+str(mstar_prescribed[ii]) +' \n'   # 
    
 
    
    fil[44]='#override DAYMAX = '+str(mstar_time[ii+1])+' \n'
    with open('MOM_override','w') as overfile2:
        overfile2.writelines(fil)
    ### MOM_override modified!

    os.system(run_executable)

    os.system('cp prog.nc '+epbl_dir)
    os.system('mv '+epbl_dir+'prog.nc '+epbl_dir+'prog_ep'+str(ii).zfill(3)+'.nc')
    
    os.system('cp surffluxes.nc '+epbl_dir)
    os.system('mv '+epbl_dir+'surffluxes.nc '+epbl_dir+'surffluxes'+str(ii).zfill(3)+'.nc')

    os.system('cp visc.nc '+epbl_dir)
    os.system('mv '+epbl_dir+'visc.nc '+epbl_dir+'visc_ep'+str(ii).zfill(3)+'.nc')

    os.system('cp RESTART/MOM.res.nc INPUT/')


